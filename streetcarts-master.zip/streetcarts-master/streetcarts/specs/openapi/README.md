Folder for OpenAPI definitions for the StreetCarts proxies.
