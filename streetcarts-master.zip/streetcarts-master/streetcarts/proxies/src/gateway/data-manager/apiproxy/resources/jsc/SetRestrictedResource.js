  try{
  context.setVariable('flow.resource.name','/PUT/v1/streetcarts/data-manager/authenticate');
}catch(e){
    throw 'Error in Javascript' + e;
}